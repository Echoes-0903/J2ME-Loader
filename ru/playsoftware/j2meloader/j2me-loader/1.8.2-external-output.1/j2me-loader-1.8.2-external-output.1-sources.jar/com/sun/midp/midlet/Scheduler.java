/*
 * Copyright 2019 Nikita Shakarun
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.sun.midp.midlet;

import javax.microedition.midlet.MIDlet;

public class Scheduler {
	private static Scheduler instance;

	public static Scheduler getScheduler() {
		if (instance == null) {
			instance = new Scheduler();
		}
		return instance;
	}

	public MIDlet getActiveMIDlet() {
		return null;
	}
}
